package App_Escola;

public class Diretor extends Pessoa{
    
    @Override
    public void Informacoes()
    {
        System.out.println("Nome do diretor: " + this.nome);
        System.out.println("ID do diretor: " + this.id);
        System.out.println("Data de contratacao do diretor: " + this.dataContrato);
    }
    
    Diretor(String nome, String id, String dataContrato)
    {
        this.nome = nome;
        this.id = id;
        this.dataContrato = dataContrato;
    }
    
    
}