package App_Escola;

import java.util.ArrayList;
import java.lang.Math;

public class Curso {
    
    ArrayList<Professor> professores;
    ArrayList<Aluno> alunosMatriculados;
    String Curso;
    String codigo;
    String descricao;
    String anoComeco;
    
    public String Relatorio()
    {
        int k = 0;
        double soma = 0;
        String R = "";
        double media = 0;
         

         
        R += "Nome do curso: " + this.Curso + "\n";
        R += "Codigo: " + this.codigo + "\n";
        R += "Descricao: " + this.descricao + "\n";
        R += "Ano de comeco: " + this.anoComeco + "\n";
        
        for(Aluno j: alunosMatriculados)
        {
            R += "Nome do aluno: " + j.nome + "\n";
            R += "Primera nota: " + j.notas.get(k) + "\n";
            media += j.notas.get(k)/alunosMatriculados.size();
            k++;
            R += "Segunda nota: " + j.notas.get(k) + "\n";
            media += j.notas.get(k)/alunosMatriculados.size();
            k--;
        }
        
        R += "Media da turma:" + media + "\n";
        
        for(Aluno j: alunosMatriculados)
        {
            soma += j.notas.get(k) - media;
            k++;
            soma += j.notas.get(k) - media;
            k--;
        }
        
        R += "Desvio padrao: " + Math.sqrt((soma*soma)/alunosMatriculados.size()) + "\n\n";
        
        return R;
    }
    
    Curso(String Curso, String codigo, String descricao, String anoComeco)
    {
        professores = new ArrayList<>();
        alunosMatriculados = new ArrayList<>();
        this.Curso = Curso;
        this.codigo = codigo;
        this.descricao = descricao;
        this.anoComeco = anoComeco;
    }
   
}