package App_Escola;

import java.util.ArrayList;

public class Aluno extends Pessoa{
    
    ArrayList<Double> notas;
    String ano;
    
     @Override
    public void Informacoes()
    {
        System.out.println("Aluno: " + this.nome);
        System.out.println("Matricula: " + this.id);
        System.out.println("Data de entrada: " + this.dataContrato);
        System.out.println("Serie: " + this.ano);
    }
    
    Aluno(String nome, String id, String dataContrato, String ano)
    {
        notas = new ArrayList<>();
        this.nome = nome;
        this.id = id;
        this.dataContrato = dataContrato;
        this.ano = ano;
    }
    
   }