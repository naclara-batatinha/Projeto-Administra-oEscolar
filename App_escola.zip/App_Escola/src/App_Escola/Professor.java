package App_Escola;

public class Professor extends Pessoa{
    
    String materia;
    
    @Override
    
    public void Informacoes()
    {
        System.out.println("Professor: " + this.nome);
        System.out.println("ID do professor: " + this.id);
        System.out.println("Data de contratacao do professor: " + this.dataContrato);
        System.out.println("Materia dada pelo professor: " + this.materia);
    }
    
    
        Professor(String nome, String id, String dataContrato, String materia)
    {
        this.nome = nome;
        this.id = id;
        this.dataContrato = dataContrato;
        this.materia = materia;
    }
}