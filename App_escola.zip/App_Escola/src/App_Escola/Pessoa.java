package App_Escola;

public abstract class Pessoa {
    
    String nome;
    String id;
    String dataContrato;
    
    public abstract void Informacoes();
}